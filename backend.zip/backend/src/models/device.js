const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Device = sequelize.define('Device', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING, allowNull: false },
  ipAddress: { type: DataTypes.STRING, allowNull: false },
  macAddress: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.ENUM('online', 'offline'), defaultValue: 'offline' },
  lastSeen: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

module.exports = Device;