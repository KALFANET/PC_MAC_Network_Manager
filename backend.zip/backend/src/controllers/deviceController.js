const Device = require('../models/device');

exports.registerDevice = async (req, res) => {
    const { name, ipAddress, macAddress, status } = req.body;
    const token = req.headers['authorization'];

    if (!token || !validateToken(token)) {
        return res.status(401).json({ message: "Unauthorized", error: "Invalid token" });
    }

    try {
        let device = await Device.findOne({ where: { macAddress } });
        if (!device) {
            device = await Device.create({ name, ipAddress, macAddress, status });
        } else {
            device.ipAddress = ipAddress;
            device.status = status;
            device.lastSeen = new Date();
            await device.save();
        }

        res.status(200).json({
            message: "Device registered successfully",
            device
        });
    } catch (error) {
        res.status(500).json({ message: "Error registering device", error: error.message });
    }
};

const validateToken = (token) => {
    try {
        jwt.verify(token, process.env.JWT_SECRET);
        return true;
    } catch (error) {
        return false;
    }
};