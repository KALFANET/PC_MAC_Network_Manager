const express = require('express');
const { registerDevice } = require('../controllers/deviceController');

const router = express.Router();

router.post('/api/devices/register', registerDevice);
router.get('/api/devices', async (req, res) => {
    const devices = await Device.findAll();
    res.json({ devices });
});

module.exports = router;